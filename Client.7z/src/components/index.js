﻿import modal from "./Modal.vue";
import dynamicButton from "./DynamicButton.vue";
import loader from "./Loader.vue";

export {
    modal,
    dynamicButton,
    loader
}
