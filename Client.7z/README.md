# client-OTM
Este é o Client da ferramenta Open Transaction Manager, que se encontra no seguinte repostório https://github.com/hemerfc/otm.git


## Project setup
```
npm install
```
